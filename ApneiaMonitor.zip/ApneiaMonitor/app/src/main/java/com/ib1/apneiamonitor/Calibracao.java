package com.ib1.apneiamonitor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Calibracao extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calibracao);
    }
}
